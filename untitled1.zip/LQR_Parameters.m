
% %  LQR �⺻ FORM. LQR�� N_BAR �޾ƾ��� % %
A=[0 1;0 -3];
B=[0 1]';
C=[1 0];
D=0;

L=acker(A',C',[-10-10i,-10+10i]);

Q=[1000 0 ;0 1]
R=1;
N=0;
lqrK=lqr(A,B,Q,R,N);

A_bar=A;
B_bar=[0 3]';
C_bar=[1 0];
D_bar=0;

Nbar=findNbar(A,B,C,D,lqrK)